$(document).ready(function(){

    // Moblile Menu Toggle
    $('.menuToggle').click(function(){
    	$('#menu').slideToggle('fast');
    	return false;
    });

});